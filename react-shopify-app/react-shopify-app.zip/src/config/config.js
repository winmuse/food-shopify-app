import React from 'react';

const ApiConfig = {
    storefrontAccessToken: '442393f9c888d0530b68bdae37f9b13b',
    domain: 'mymymy1234.myshopify.com',
    //price_list: 'lite'
    price_list: 'standard'
    //price_list: 'premium'
    //price_list: 'unlimit'
}

export default ApiConfig;