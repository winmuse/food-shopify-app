export const firebaseConfig = {
    apiKey: "AIzaSyAhJ2fw0FrhAv14tqRheDczM_IJOnxxDhI",
    authDomain: "pos-app-3ec45.firebaseapp.com",
    databaseURL: "https://pos-app-3ec45.firebaseio.com",
    projectId: "pos-app-3ec45",
    storageBucket: "pos-app-3ec45.appspot.com",
    messagingSenderId: "200234289965",
    appId: "1:200234289965:web:833a69d4e195e65ffb21a4",
    measurementId: "G-JBGCNPM9PS"
};