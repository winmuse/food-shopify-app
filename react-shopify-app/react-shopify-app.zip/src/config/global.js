// import React from 'react';
// var Name = 'empty';
// // declare var const ApiConfig = {
// //     storefrontAccessToken: '442393f9c888d0530b68bdae37f9b13b',
// //     domain: 'mymymy1234.myshopify.com',
// //     //price_list: 'lite'
// //     price_list: 'standard'
// //     //price_list: 'premium'
// //     //price_list: 'unlimit'
// // }

// export default window.Name;
global.storefrontAccessToken = "";
global.domain = "";
global.price_list = "";

global.api_domain = "https://app.excuseme.jp";
//global.api_domain = "http://localhost:5000";