import React from "react";
import {createRenderer} from "../style/Renderer";

const RenderBlank = createRenderer()

export default RenderBlank
