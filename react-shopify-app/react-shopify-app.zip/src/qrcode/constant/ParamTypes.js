export const ParamTypes = ({
    TEXT_EDITOR: 1,
    SELECTOR: 2,
    COLOR_EDITOR: 3,
    CHECK_BOX: 4,
    UPLOAD_BUTTON: 5
});
