import {actionTypes} from "../constant/ActionTypes";
import {handleStyle} from "../utils/gaHelper";

export const genQRInfo = text => ({
    type: actionTypes.GENERATE_QR_INFO,
    text
})

export const changeLicense = text => ({
    type: actionTypes.CHANGELICENSE,
    text
})

export const ChangeAuthen = text => ({
    type: actionTypes.CHANGEAUTHEN,
    text
})

export const changeQRurl = text => ({
    type: actionTypes.CHANGEQRURL,
    text
})


export const changeStyle = (rendererIndex, rendererType, value) => {
    handleStyle(value);
    return {
        type: actionTypes.CHANGE_STYLE,
        rendererIndex, rendererType, value
    }
}

export const changeCorrectLevel = (correctLevel) => ({
    type: actionTypes.CHANGE_CORRECT_LEVEL,
    correctLevel
})

export const createParam = (paramInfo, paramValue) => ({
    type: actionTypes.CREATE_PARAM,
    paramInfo, paramValue
})

export const changeParam = (rendererIndex, paramIndex, value) => {

    return {
        type: actionTypes.CHANGE_PARAM,
        rendererIndex, paramIndex, value
    };
}

export const loadDownloadData = (data) => ({
    type: actionTypes.LOAD_DOWNLOAD_DATA,
    data
})
