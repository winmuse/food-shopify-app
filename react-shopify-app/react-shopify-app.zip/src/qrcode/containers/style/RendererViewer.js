import {connect} from 'react-redux';
import Renderer from "../../components/style/Renderer";
import {fillEmptyWith} from "../../utils/util";

const mapStateToProps = (state, ownProps) => ({
    rendererType: ownProps.rendererType,
    rendererIndex: ownProps.index,
    qrcode: state.qrcode,
    params: fillEmptyWith(state.paramValue[0].slice(), 0),
    selected: state.selectedIndex === ownProps.index,
})

const mapDispatchToProps = (dispatch, ownProps) => ({
    setParamInfo: (params) => ownProps.setParamInfo(ownProps.index, params)
})


export default connect(mapStateToProps, mapDispatchToProps)(Renderer)
